{
  cout << "Hello world" << endl;
  exit(0);
}
